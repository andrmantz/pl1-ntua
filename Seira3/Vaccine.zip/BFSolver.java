import java.util.*;

/* A class that implements a solver that explores the search space
 * using breadth-first search (BFS).  This leads to a solution that
 * is optimal in the number of moves from the initial to the final
 * state.
 */
public class BFSolver implements Solver {
  @Override
  public void solve (State initial) {
    Set<State> seen = new HashSet<>();
    Queue<State> remaining = new ArrayDeque<>();
   // int j=0;

    seen.add(initial);
    remaining.add(initial);
    while (!remaining.isEmpty()) {
     // System.out.println(remaining.size());
    //  j++;
    //  if (j==10000000){
    //    System.gc();
    //  }
      State s = remaining.remove();
    
      for (State n : s.next()) {
        if (n.isFinal()){
          printSolution(n);
          System.out.println();
          return ;
        }
        if (!seen.contains(n)){
          remaining.add(n);
          seen.add(n);
        }
      }
    }
    System.out.println("No solution found!");
    return;
  }

  private static void printSolution(State s) {

    if (s.getPrevious()!=null){      
        printSolution(s.getPrevious());
    }
    System.out.print(s.getAction());
}
}
