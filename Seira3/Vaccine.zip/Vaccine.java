import java.io.*;
import java.util.*;
//import java.lang.*;

public class Vaccine {
    // The main function.
    public static void main(String args[]) {
        
        File infile = new File(args[0]);
        int i;
        String input;
        Solver solver = new BFSolver();
        try{
            BufferedReader br = new BufferedReader(new FileReader(infile));
            br.readLine();//diabazo to t
            while ((input=br.readLine())!= null){ 
                if (input.length()==1){
                    System.out.println("p");
                    continue;
                }
                if (input.length()==2){
                    System.out.println("pp");
                    continue;
                }
                
                Stack<Character> stack_1 = new Stack<>();
                Stack<Character> stack_2 = new Stack<>();
                List<Integer> Flags = new ArrayList<>();

                stack_2.push(input.charAt(input.length()-1));
                for (i=0; i<input.length()-1; i++){
                    stack_1.add(input.charAt(i));
                }
                if (stack_2.get(0)=='A'){
                    Flags.add(2);
                    Flags.add(0);
                    Flags.add(0);
                    Flags.add(0);
                }
                if (stack_2.get(0)=='U'){
                    Flags.add(0);
                    Flags.add(2);
                    Flags.add(0);
                    Flags.add(0);
                }
                if (stack_2.get(0)=='C'){
                    Flags.add(0);
                    Flags.add(0);
                    Flags.add(2);
                    Flags.add(0);
                }
                if (stack_2.get(0)=='G'){
                    Flags.add(0);
                    Flags.add(0);
                    Flags.add(0);
                    Flags.add(2);
                }
               // System.out.println(stack_1);
                State initial = new NewvaccineState(stack_1, stack_2, null, 'p', Flags);
                solver.solve(initial);
               // System.out.print('p');//i proti kinisi einai panta p
               // if (result == null) {
               //     System.out.println("No solution found.");
               // } else {
                    
               //     printSolution(result);
               // }
                //System.out.println();
                System.gc();
            }
            br.close();
           // System.out.print(getUsedMemory());
            
        } catch(Exception e){}
    }

    // A recursive function to print the states from the initial to the final.
    /*private static void printSolution(State s) {

        if (s.getPrevious()!=null){      
            printSolution(s.getPrevious());
        }
        System.out.print(s.getAction());
    }*/

   // public static long getUsedMemory() {
   //     return Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    //}
      
}